# FRIDAY OS Test Suite
